import { serve } from "https://deno.land/std@0.181.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.33.0";


const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

serve(async () => {
  const res = await fetch(`${Deno.env.get("WC_STORE_URL")}/wp-json/wc/v3/orders?consumer_key=${Deno.env.get('WC_CONSUMER_KEY')}&consumer_secret=${Deno.env.get('WC_CONSUMER_SECRET')}`, {
    headers: {
      'Authorization': 'Basic ' + btoa(`${Deno.env.get('WC_CONSUMER_KEY')}:${Deno.env.get('WC_CONSUMER_SECRET')}`)
    }
  });

  const orders = await res.json();

  console.log('orders: ' + JSON.stringify(orders));

  for (const order of orders) {
    console.log('order::' + JSON.stringify(order));
    // Insert or update customer
    const { billing } = order;

    const customerPayload = {
      wc_customer_id: order.customer_id || null,
      name: `${billing.first_name} ${billing.last_name}`,
      email: billing.email,
      phone: billing.phone,
      address: {
        street: billing.address_1,
        city: billing.city,
        postcode: billing.postcode
      }
    };

    const { data: customerData, error } = await supabase
      .from('customers')
      .upsert(customerPayload, {
        onConflict: 'email'
      })
      .select();

    if (error) {
      console.error('Customer upsert error:', error);
      throw error;
    }

    if (!customerData || customerData.length === 0) {
      throw new Error('Customer upsert returned no rows');
    }

    console.log('customerData.length::' + customerData.length)
    console.log('customerData::' + JSON.stringify(customerData))
    const customer_id = customerData[0].id;
    const phone = customerData[0].phone;

    // Check if first order
    const { count, cnterror } = await supabase
      .from('orders')
      .select('id', { count: 'exact', head: true })
      .eq('customer_id', customer_id);

    if (cnterror) {
      console.error('Order count error:', cnterror);
      throw cnterror;
    }

    const first_order = count === 0;

    const orderPayload = {
      wc_order_id: order.id,
      store_id: 1,  // map to your store
      status: 'NEW',
      customer_id,
      total: order.total,
      payment_method: order.payment_method,
      order_notes: order.customer_note,
      first_order,
      created_at: order.date_created
    };

    // Insert order
    const { data: orderData, ordererror } = await supabase.from('orders').upsert(
      orderPayload, { onConflict: ['wc_order_id']}).select();

    if (ordererror) {
      console.error('Order upsert error:', ordererror);
      throw ordererror;
    }

    console.log('orderData::' + orderData);
    const order_id = orderData[0].id;

    
    // Insert order items
    for (const item of order.line_items) {
      const orderItemPayload = {
        order_id,
        name: item.name,
        quantity: item.quantity,
        price: item.price,
        meta: item.meta_data
      };
      const {orderItemError} = await supabase.from('order_items').upsert(orderItemPayload);
      if (orderItemError) {
       console.error('Order item upsert error:', orderItemError);
       throw orderItemError;
      } 
    }
  }

  return new Response(JSON.stringify({ message: 'Orders synced', count: orders.length }));
});
